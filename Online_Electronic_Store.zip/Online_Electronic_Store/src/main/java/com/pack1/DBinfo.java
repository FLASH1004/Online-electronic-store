package com.pack1;

public interface DBinfo 
{

	String DBUrl="jdbc:oracle:thin:@//localhost:1521/orclXDB";
	String DBUname="system";
	String DBPwd="shivam00";
}

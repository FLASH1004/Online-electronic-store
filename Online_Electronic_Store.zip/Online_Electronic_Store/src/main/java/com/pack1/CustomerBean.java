package com.pack1;

import java.io.Serializable;

public class CustomerBean implements Serializable 
{
	private String uName;
	private String uPwd;
	private String uFname;
	private String uLname;
	private String uAddrs;
	private String uMail;
	private String uPno;
	
	public CustomerBean() {}

	public String getuName() {
		return uName;
	}

	public void setuName(String uName) {
		this.uName = uName;
	}

	public String getuPwd() {
		return uPwd;
	}

	public void setuPwd(String uPwd) {
		this.uPwd = uPwd;
	}

	public String getuFname() {
		return uFname;
	}

	public void setuFname(String uFname) {
		this.uFname = uFname;
	}

	public String getuLname() {
		return uLname;
	}

	public void setuLname(String uLname) {
		this.uLname = uLname;
	}

	public String getuAddrs() {
		return uAddrs;
	}

	public void setuAddrs(String uAddrs) {
		this.uAddrs = uAddrs;
	}

	public String getuMail() {
		return uMail;
	}

	public void setuMail(String uMail) {
		this.uMail = uMail;
	}

	public String getuPno() {
		return uPno;
	}

	public void setuPno(String uPno) {
		this.uPno = uPno;
	}
	
	
}

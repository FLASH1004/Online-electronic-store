package com.pack1;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class CustomerRegisterDAO 
{
	public int customerRegister(CustomerBean cb)
	{
		int rowCount = 0;
		
		try
		{
			Connection con = DBConnect.getCon();
		 	PreparedStatement pstmt = con.prepareStatement("insert into customer values(?,?,?,?,?,?,?)");
		 	pstmt.setString(1, cb.getuName());
		 	pstmt.setString(2, cb.getuPwd());
		 	pstmt.setString(3, cb.getuFname());
		 	pstmt.setString(4, cb.getuLname());
		 	pstmt.setString(5, cb.getuAddrs());
		 	pstmt.setString(6, cb.getuMail());
		 	pstmt.setString(7, cb.getuPno());
		 	
		 	rowCount = pstmt.executeUpdate();;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		return rowCount;
	}
}

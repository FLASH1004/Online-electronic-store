package com.pack1;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/crs")
public class CustomerRegistrationServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		CustomerBean cbean = new CustomerBean();
		cbean.setuName(req.getParameter("uname"));
		cbean.setuPwd(req.getParameter("upwd"));
		cbean.setuFname(req.getParameter("ufname"));
		cbean.setuLname(req.getParameter("ulname"));
		cbean.setuAddrs(req.getParameter("uaddrs"));
		cbean.setuMail(req.getParameter("umail"));
		cbean.setuPno(req.getParameter("upno"));
		
		CustomerRegisterDAO crdao = new CustomerRegisterDAO();
		int rowCount = crdao.customerRegister(cbean);
		
		if(rowCount>0)
		{
			RequestDispatcher rd = req.getRequestDispatcher("CustomerLogin.html");
			rd.forward(req, res);
		}
		else
		{
			req.setAttribute("msg", "Something Went Wrong...");
			RequestDispatcher rd = req.getRequestDispatcher("CustomerRegister.html");
			rd.forward(req, res);
		}
	}
	
}

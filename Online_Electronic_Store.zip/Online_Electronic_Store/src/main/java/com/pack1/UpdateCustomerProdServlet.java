package com.pack1;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/updateCustomer")
public class UpdateCustomerProdServlet extends HttpServlet
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException 
	{
		HttpSession session = req.getSession(false);
		
		if(session == null)
		{
			req.setAttribute("msg", "Session Expired!!!");
			RequestDispatcher rd = req.getRequestDispatcher("CustomerLogin.html");
			rd.forward(req, res);
		}
		String pcode = req.getParameter("pcode");
        int reqQty = Integer.parseInt(req.getParameter("req")); // Quantity required by the customer
        
     // Retrieve product list from session
        ArrayList<ProductBean> productList = (ArrayList<ProductBean>) session.getAttribute("ProductsList");
        
     // Find the product in the list by matching product code
        ProductBean selectedProduct = null;
        for (ProductBean product : productList) 
        {
            if (pcode.equals(product.getpCode())) 
            {
                selectedProduct = product;
                break;
            }
        }
        
        if (selectedProduct == null)
        {
            req.setAttribute("msg", "Product not found.");
            RequestDispatcher rd = req.getRequestDispatcher("BuyProduct.jsp");
            rd.forward(req, res);
            return;
        }
        
     // Call DAO to update the product in the database
        UpdateCustomerProdDAO ucpdao = new UpdateCustomerProdDAO();
        int rowCount = ucpdao.updateCustomerPro(selectedProduct, reqQty);
        
        if (rowCount > 0) 
        {
        	req.setAttribute("reqQty", reqQty);
            req.setAttribute("pbean", selectedProduct); // Pass the product bean
            RequestDispatcher rd = req.getRequestDispatcher("OrderConfirmed.jsp");
            rd.forward(req, res);
        }
	}
	
}

package com.pack1;

import java.sql.Connection;
import java.sql.PreparedStatement;

public class UpdateCustomerProdDAO
{
	public int updateCustomerPro(ProductBean pb, int reqQty) 
	{
		int rowCount = 0;
		
		try
		{
			Connection con = DBConnect.getCon();
			PreparedStatement pstmt = con.prepareStatement("update product set pqty = pqty-? where pcode=?");
			pstmt.setInt(1, reqQty);
			pstmt.setString(2, pb.getpCode());
			
			rowCount = pstmt.executeUpdate();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		
		return rowCount;
	}
}

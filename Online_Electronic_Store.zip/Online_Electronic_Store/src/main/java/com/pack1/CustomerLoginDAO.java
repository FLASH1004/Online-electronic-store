package com.pack1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class CustomerLoginDAO 
{
	public CustomerBean checkCustomerLogin(String uname, String upwd)
	{
		CustomerBean cbean = null;
		
		try
		{
			Connection con = DBConnect.getCon();
			PreparedStatement pstmt = con.prepareStatement("select * from customer where uname = ? and pword = ?");
			pstmt.setString(1, uname);
			pstmt.setString(2, upwd);
			
			ResultSet rs = pstmt.executeQuery();
			
			if(rs.next())
			{
				cbean = new CustomerBean();
				cbean.setuName(rs.getString(1));
				cbean.setuPwd(rs.getString(2));
				cbean.setuFname(rs.getString(3));
				cbean.setuLname(rs.getString(4));
				cbean.setuAddrs(rs.getString(5));
				cbean.setuMail(rs.getString(6));
				cbean.setuPno(rs.getString(7));
				
			}
		}
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		return cbean; 
	}
}

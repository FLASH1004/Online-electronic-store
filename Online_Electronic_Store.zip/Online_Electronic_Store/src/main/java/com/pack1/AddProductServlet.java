package com.pack1;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/aps")
public class AddProductServlet extends HttpServlet 
{
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException
	{
		HttpSession session = req.getSession();
		
		if(session == null)
		{
			req.setAttribute("msg", "Session Expired..!!!");
			RequestDispatcher rd = req.getRequestDispatcher("AdminLogin.html");
			rd.forward(req, res);
		}
		else
		{
			ProductBean pbean = new ProductBean();
			pbean.setpCode(req.getParameter("pcode"));
			pbean.setpName(req.getParameter("pname"));
			pbean.setpCompany(req.getParameter("pcompany"));
			pbean.setpPrice(req.getParameter("pprice"));
			pbean.setpQty(req.getParameter("pqty"));
			
			AddProductDAO apdao = new AddProductDAO();
			int rowCount = apdao.insertProduct(pbean);
			
			if(rowCount>0)
			{
				req.setAttribute("msg", "Product Details added Successfully!!!!");
				RequestDispatcher rd = req.getRequestDispatcher("AddProduct.jsp");
				rd.forward(req, res);
			}
			else
			{
				req.setAttribute("msg", "Product NOT Inserted, try again!!!");
				RequestDispatcher rd = req.getRequestDispatcher("AddProduct.jsp");
				rd.forward(req, res);
			}
		}
			
	}
}
